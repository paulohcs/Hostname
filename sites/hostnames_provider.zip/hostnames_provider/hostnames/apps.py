from django.apps import AppConfig


class HostnamesConfig(AppConfig):
    name = 'hostnames'
